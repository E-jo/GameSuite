package com.murach.hangtest;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.view.View.OnClickListener;


import android.os.Bundle;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {
    private Button easyButton;
    private Button hardButton;
    private Button c4Button;
    private Button sSButton;
    private Button settingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("ac2", "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        easyButton = (Button) findViewById(R.id.buttonEasy);
        hardButton = (Button) findViewById(R.id.buttonHard);
        c4Button = (Button) findViewById(R.id.buttonC4);
        sSButton = (Button) findViewById(R.id.buttonSS);
        settingsButton = (Button) findViewById(R.id.buttonSettings);
        Log.d("ac2", "onCreate");

        c4Button.setOnClickListener(this);
        easyButton.setOnClickListener(this);
        hardButton.setOnClickListener(this);
        sSButton.setOnClickListener(this);
        settingsButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        Log.d("ac2", "click");
        if (v.getId() == R.id.buttonEasy) {
            intent.putExtra("filename", "common.txt");
            Log.d("ac2", "easy clicked");
        } else if (v.getId() == R.id.buttonHard) {
            intent.putExtra("filename", "usa2.txt");
            Log.d("ac2", "hard clicked");
        } else if (v.getId() == R.id.buttonSS) {
            intent = new Intent(this, MainActivity4.class);
            startActivity(intent);
        } else if (v.getId() == R.id.buttonC4) {
            intent = new Intent(this, MainActivity3.class);
            startActivity(intent);
        } else if (v.getId() == R.id.buttonSettings) {
            intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }
        try {
            startActivity(intent);
        } catch (Exception e) {
            Log.d("ac2", "error starting activity intent");
        }
    }
}