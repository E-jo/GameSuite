package com.murach.hangtest;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Button;
import android.content.res.AssetManager;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import android.os.Bundle;
import java.util.Collections;
import java.util.ArrayList;
import java.lang.StringBuilder;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import android.content.Intent;

public class MainActivity extends AppCompatActivity
        implements OnClickListener, OnEditorActionListener {

    private int winTotal = 0;
    private int lossTotal = 0;
    private EditText guessEditText;
    private TextView displayTextView;
    private TextView msgTextView;
    private TextView winTextView;
    private TextView lossTextView;
    private TextView remainTextView;
    private TextView missesTextView;
    private ImageView hangView;
    private Button guessButton;
    private Button resetButton;
    private Button solutionButton;
    private Button wordlistButton;
    private ArrayList<String> wordList = new ArrayList<>();
    private ArrayList<String> misses = new ArrayList<>();
    private StringBuilder displayWord = new StringBuilder();
    private StringBuilder missedLetters = new StringBuilder();
    private String wordString;
    private String guess;
    private SharedPreferences savedValues;
    private static final String TAG = "HangTestActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        Log.d(TAG, "onCreate called");
        //get widget references
        guessEditText = (EditText) findViewById(R.id.editTextGuess);
        displayTextView = (TextView) findViewById(R.id.textDisplay);
        msgTextView = (TextView) findViewById(R.id.textMsg);
        winTextView = (TextView) findViewById(R.id.textWins);
        lossTextView = (TextView) findViewById(R.id.textLosses);
        remainTextView = (TextView) findViewById(R.id.textRemaining);
        missesTextView = (TextView) findViewById(R.id.textMisses);
        guessButton = (Button) findViewById(R.id.buttonGuess);
        resetButton = (Button) findViewById(R.id.buttonReset);
        wordlistButton = (Button) findViewById(R.id.buttonWL);
        solutionButton = (Button) findViewById(R.id.buttonSolution);
        hangView = (ImageView) findViewById(R.id.imageView);

        //listener for text box
        guessEditText.setOnEditorActionListener(this);

        //button click listeners
        solutionButton.setOnClickListener(this);
        guessButton.setOnClickListener(this);
        resetButton.setOnClickListener(this);
        wordlistButton.setOnClickListener(this);

        Intent intent = getIntent();
        String filename = intent.getStringExtra("filename");

        //load word list from text file
        AssetManager am = this.getAssets();
        try {
            InputStream in = am.open(filename);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null) {
                wordList.add(line);
            }
            reader.close();
        } catch (Exception e) {
            System.err.format("Exception occurred trying to read wordlist.");
            e.printStackTrace();
        }
        resetDisplayWord();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainactivity2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_simon:
                startActivity(new Intent(getApplicationContext(), MainActivity4.class));
                return true;
            case R.id.menu_c4:
                startActivity(new Intent(getApplicationContext(), MainActivity3.class));
                return true;
            case R.id.menu_settings:
                startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onPause() {
        Editor editor = savedValues.edit();
        editor.putString("wordString", wordString);
        editor.putString("missedLetters", missedLetters.toString());
        editor.putString("displayWord", displayWord.toString());
        editor.putInt("winTotal", winTotal);
        editor.putInt("lossTotal", lossTotal);
        editor.commit();
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();

        String missesString = savedValues.getString("missedLetters", "");
        misses.clear();
        for (int i = 0; i < missesString.length(); i++) {
            misses.add(missesString.substring(i, i + 1));
        }
        Log.d(TAG, "missesString: " + missesString);
        Log.d(TAG, "misses: " + misses);
        missedLetters.delete(0, missedLetters.length());

        for (String miss : misses) {
            missedLetters.append(miss);

        }
        Log.d(TAG, "missedLetters: " + missedLetters.toString().replace("[", "").replace("]", ""));

        remainTextView.setText(7 - misses.size() + " Guesses Remaining");
        hangView.setImageResource(R.drawable.hang + misses.size());
        missesTextView.setText("Missed:  " + missedLetters.toString());

        winTotal = savedValues.getInt("winTotal", 0);
        lossTotal = savedValues.getInt("lossTotal", 0);
        String displayWordString = savedValues.getString("displayWord", "");
        Log.d(TAG, "displayWordStr: " + displayWordString);
        displayWord = new StringBuilder(displayWordString);
        Log.d(TAG, "displayWord: " + displayWord);
        displayTextView.setText(displayWord);
        wordString = savedValues.getString("wordString", "");
        Log.d(TAG, "wordString: " + wordString);
        winTextView.setText("Wins: " + winTotal);
        lossTextView.setText("Losses: " + lossTotal);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.buttonReset) {
            resetDisplayWord();
        } else if(v.getId() == R.id.buttonWL) {
            Log.d(TAG, "wordlist clicked");
            Intent intent = new Intent(this, MainActivity2.class);
            startActivity(intent);
        } else if (v.getId() == R.id.buttonGuess) {
            checkGuess(guessEditText.getText().toString());
        } else if (v.getId() == R.id.buttonSolution) {
            msgTextView.setText(wordString);
            if (msgTextView.getVisibility() == View.VISIBLE) {
                msgTextView.setVisibility(View.INVISIBLE);
            } else if (msgTextView.getVisibility() == View.INVISIBLE) {
                msgTextView.setVisibility((View.VISIBLE));
            }
        }
    }
    public void resetDisplayWord() {
        Log.d(TAG, "resetDisplayWord called");
        //reset hangman graphic
        hangView.setImageResource(R.drawable.hang);
        
        //reset misses and associated stringbuilder
        misses.clear();
        for (String miss : misses) {
            missedLetters.append(miss);
        }
        remainTextView.setText(7 - misses.size() + " Guesses Remaining");

        //shuffle word list and get new word
        Collections.shuffle(wordList);
        wordString = wordList.get(0);

        //create appropriate length masked display word
        displayWord.delete(0, displayWord.length());
        for (int i = 0; i < wordString.length(); i++) {
            displayWord.append("*");
        }

        //reset display and misses text views
        displayTextView.setText(displayWord);
        missesTextView.setText("Missed:  " + missedLetters);
        missedLetters.delete(0, missedLetters.length());

        //reset dev mode answer window
        msgTextView.setText(wordString);
    }

    public boolean checkGuess(String s) {
        String guess = s.toLowerCase();
        Log.d(TAG, "checkGuess called");

        //check for previously guessed or blank - clear entry and exit
        if (misses.contains(guess) || guess.isEmpty()) {
            Log.d(TAG, "bad guess caught");
            guessEditText.setText("");
            return false;
        }

        //check for solved puzzle or end of game and reset
        if (misses.size() == 7 || displayWord.toString().indexOf("*") == -1) {
            resetDisplayWord();
            return false;
        }

        boolean found = false;
        for (int m = 0; m < wordString.length(); m++) {
            if (wordString.substring(m, m + 1).equalsIgnoreCase(guess)) {
                displayWord.replace(m, m + 1, guess);
                found = true;
            }
        }
        displayTextView.setText(displayWord);
        guessEditText.setText("");
        if (found == true) {
            if (displayWord.toString().indexOf("*") == -1) {
                remainTextView.setText("Solved!  " + wordString);
                winTotal += 1;
                winTextView.setText("Wins: " + winTotal);
            }
            return true;
        } else {
            misses.add(guess);
            hangView.setImageResource(R.drawable.hang + misses.size());
            remainTextView.setText(7 - misses.size() + " Guesses Remaining");
            for (String miss : misses) {
                missedLetters.append(miss);
            }
            missesTextView.setText("Missed:  " + missedLetters);
            missedLetters.delete(0, missedLetters.length());
            if (misses.size() == 7) {
                lossTotal += 1;
                remainTextView.setText("Lost!\t" + wordString);
                lossTextView.setText("Losses: " + lossTotal);
            }
            return false;
        }
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            checkGuess(guessEditText.getText().toString());
            return true;
        } else {
            return false;
        }
    }
}
