package com.murach.hangtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainactivity2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_simon:
                startActivity(new Intent(getApplicationContext(), MainActivity4.class));
                return true;
            case R.id.menu_c4:
                startActivity(new Intent(getApplicationContext(), MainActivity3.class));
                return true;
            case R.id.menu_hang:
                startActivity(new Intent(getApplicationContext(), MainActivity2.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}