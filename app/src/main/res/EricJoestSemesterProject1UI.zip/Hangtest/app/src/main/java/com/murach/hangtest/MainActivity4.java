package com.murach.hangtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.CountDownTimer;
import java.util.Random;
import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity implements View.OnTouchListener, View.OnClickListener {
    private TextView tvRed;
    private TextView tvGreen;
    private TextView tvYel;
    private TextView tvBlue;
    private TextView tvSequence;
    private TextView tvWin;
    private TextView tvLoss;
    private TextView tvStreak;
    private Button btnSimon;
    private Button btnGen;
    private ArrayList<String> sequence1 = new ArrayList<>();
    private ArrayList<String> sequence2 = new ArrayList<>();
    private int player;
    public int count = 1;
    private int win;
    private int loss;
    private int streak;
    private boolean clearing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        tvRed = (TextView) findViewById(R.id.tvRed);
        tvGreen = (TextView) findViewById(R.id.tvGreen);
        tvYel = (TextView) findViewById(R.id.tvYel);
        tvBlue = (TextView) findViewById(R.id.tvBlue);
        tvSequence = (TextView) findViewById(R.id.tvSequence);
        tvWin = (TextView) findViewById(R.id.tvWin);
        tvLoss = (TextView) findViewById(R.id.tvLoss);
        tvStreak = (TextView) findViewById(R.id.tvStreak);
        btnSimon = (Button) findViewById(R.id.btnSimon);
        btnGen = (Button) findViewById(R.id.btnGen);
        tvRed.setOnTouchListener(this);
        tvBlue.setOnTouchListener(this);
        tvYel.setOnTouchListener(this);
        tvGreen.setOnTouchListener(this);
        tvYel.setOnClickListener(this);
        tvRed.setOnClickListener(this);
        tvGreen.setOnClickListener(this);
        tvBlue.setOnClickListener(this);
        btnSimon.setOnClickListener(this);
        btnGen.setOnClickListener(this);
        player = 1;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainactivity4, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_c4:
                startActivity(new Intent(getApplicationContext(), MainActivity3.class));
                return true;
            case R.id.menu_hang:
                startActivity(new Intent(getApplicationContext(), MainActivity2.class));
                return true;
            case R.id.menu_settings:
                startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();
        switch (v.getId()) {
            case R.id.tvRed:
                if (action == MotionEvent.ACTION_DOWN) {
                    MediaPlayer noteD = MediaPlayer.create(this, R.raw.note_d);
                    noteD.start();
                    tvRed.setBackgroundResource(R.drawable.ssredborder);
                } else if (action == MotionEvent.ACTION_UP) {
                    tvRed.setBackgroundResource(R.drawable.ssred);
                    if (player == 1) {
                        sequence1.add("Red");
                        tvSequence.setText(sequence1.toString());
                    } else {
                        sequence2.add("Red");
                        tvSequence.setText(sequence2.toString());
                    }
                }
                return true;
            case R.id.tvGreen:
                if (action == MotionEvent.ACTION_DOWN) {
                    MediaPlayer noteE = MediaPlayer.create(this, R.raw.note_e);
                    noteE.start();
                    tvGreen.setBackgroundResource(R.drawable.ssgreenborder);
                } else if (action == MotionEvent.ACTION_UP) {
                    tvGreen.setBackgroundResource(R.drawable.ssgreen);
                    if (player == 1) {
                        sequence1.add("Green");
                        tvSequence.setText(sequence1.toString());
                    } else {
                        sequence2.add("Green");
                        tvSequence.setText(sequence2.toString());
                    }
                }
                return true;
            case R.id.tvYel:
                if (action == MotionEvent.ACTION_DOWN) {
                    MediaPlayer noteA = MediaPlayer.create(this, R.raw.note_a);
                    noteA.start();
                    tvYel.setBackgroundResource(R.drawable.ssyelborder);
                } else if (action == MotionEvent.ACTION_UP) {
                    tvYel.setBackgroundResource(R.drawable.ssyel);
                    if (player == 1) {
                        sequence1.add("Yellow");
                        tvSequence.setText(sequence1.toString());
                    } else {
                        sequence2.add("Yellow");
                        tvSequence.setText(sequence2.toString());
                    }
                }
                return true;
            case R.id.tvBlue:
                if (action == MotionEvent.ACTION_DOWN) {
                    MediaPlayer noteC = MediaPlayer.create(this, R.raw.note_c);
                    noteC.start();
                    tvBlue.setBackgroundResource(R.drawable.ssblueborder);
                } else if (action == MotionEvent.ACTION_UP) {
                    tvBlue.setBackgroundResource(R.drawable.ssblue);
                    if (player == 1) {
                        sequence1.add("Blue");
                        tvSequence.setText(sequence1.toString());
                    } else {
                        sequence2.add("Blue");
                        tvSequence.setText(sequence2.toString());
                    }
                }
                return true;
        }
        return false;
    }

    private void generateSeq() {
        player = 1;
        clearing = false;
        //Toast.makeText(this, "gen seq called. count is " + count, Toast.LENGTH_SHORT).show();
        sequence1.clear();
        sequence2.clear();

        new CountDownTimer(count * 2000, 1000) {
            public void onTick(long millisUntilFinished) {
                if (!clearing) {
                    //highlight one color with a border and add to sequence
                    Random random = new Random();
                    int rNum = random.nextInt(4);
                    switch (rNum) {
                        case 0:
                            tvRed.setBackgroundResource(R.drawable.ssredborder);
                            tvRed.callOnClick();
                            break;
                        case 1:
                            tvYel.setBackgroundResource(R.drawable.ssyelborder);
                            tvYel.callOnClick();
                            break;
                        case 2:
                            tvGreen.setBackgroundResource(R.drawable.ssgreenborder);
                            tvGreen.callOnClick();
                            break;
                        case 3:
                            tvBlue.setBackgroundResource(R.drawable.ssblueborder);
                            tvBlue.callOnClick();
                            break;
                    }
                    clearing = true;
                } else {
                    //clear borders
                    tvBlue.setBackgroundResource(R.drawable.ssblue);
                    tvRed.setBackgroundResource(R.drawable.ssred);
                    tvYel.setBackgroundResource(R.drawable.ssyel);
                    tvGreen.setBackgroundResource(R.drawable.ssgreen);
                    clearing = false;
                }
            }
            public void onFinish() {
                btnSimon.callOnClick();
            }
        }.start();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnSimon) {
            if (player == 2) {
                if (sequence2.equals(sequence1)) {
                    Toast.makeText(this, "Win!", Toast.LENGTH_SHORT).show();
                    streak = (count > streak ? count: streak);
                    count++;
                    win++;
                } else {
                    Toast.makeText(this, "Loss!", Toast.LENGTH_SHORT).show();
                    loss++;
                    count = 1;
                }
                tvWin.setText("Wins: " + win);
                tvLoss.setText("Losses: " + loss);
                tvStreak.setText("Longest streak: " + streak);
                player = 1;
                sequence1.clear();
                sequence2.clear();
                tvSequence.setText(sequence1.toString());
            } else {
                player = 2;
                tvSequence.setText(sequence2.toString());
            }
        } else if (view.getId() == R.id.btnGen) {
            generateSeq();
        } else if (view.getId() == R.id.tvYel) {
            MediaPlayer noteA = MediaPlayer.create(this, R.raw.note_a);
            noteA.start();
            if (player == 1) {
                sequence1.add("Yellow");
                tvSequence.setText(sequence1.toString());
            } else {
                sequence2.add("Yellow");
                tvSequence.setText(sequence2.toString());
            }
        } else if (view.getId() == R.id.tvBlue) {
            MediaPlayer noteC = MediaPlayer.create(this, R.raw.note_c);
            noteC.start();
            if (player == 1) {
                sequence1.add("Blue");
                tvSequence.setText(sequence1.toString());
            } else {
                sequence2.add("Blue");
                tvSequence.setText(sequence2.toString());
            }
        } else if (view.getId() == R.id.tvRed) {
            MediaPlayer noteD = MediaPlayer.create(this, R.raw.note_d);
            noteD.start();
            if (player == 1) {
                sequence1.add("Red");
                tvSequence.setText(sequence1.toString());
            } else {
                sequence2.add("Red");
                tvSequence.setText(sequence2.toString());
            }
        } else if (view.getId() == R.id.tvGreen) {
            MediaPlayer noteE = MediaPlayer.create(this, R.raw.note_e);
            noteE.start();
            if (player == 1) {
                sequence1.add("Green");
                tvSequence.setText(sequence1.toString());
            } else {
                sequence2.add("Green");
                tvSequence.setText(sequence2.toString());
            }
        }
    }
}